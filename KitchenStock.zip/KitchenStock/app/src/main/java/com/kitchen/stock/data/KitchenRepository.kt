package com.kitchen.stock.data

import kotlinx.coroutines.flow.Flow

class KitchenRepository(private val dao: KitchenDao) {
    fun getAllItems(): Flow<List<KitchenItem>> = dao.getAllItems()
    fun searchItems(query: String): Flow<List<KitchenItem>> =
        if (query.isBlank()) dao.getAllItems() else dao.searchItems(query)

    suspend fun addItem(item: KitchenItem) = dao.insertItem(item)
    suspend fun updateItem(item: KitchenItem) = dao.updateItem(item)
    suspend fun deleteItem(item: KitchenItem) = dao.deleteItem(item)

    suspend fun useItem(item: KitchenItem, usedQty: Double) {
        val remaining = item.quantity - usedQty
        if (remaining <= 0.0) dao.deleteItem(item)
        else dao.updateQuantity(item.id, remaining)
    }
}
