package com.kitchen.stock.ui

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.kitchen.stock.data.KitchenItem
import com.kitchen.stock.theme.*
import java.io.File

val EMOJIS = listOf("🍚","🫙","🧅","🍅","🥛","🧄","🌶️","🫑","🥕","🥦","🍋","🧈","🥚","🍞","🧂","🍯","🫒","🥩","🐟","🍗","🧀","🍄","🫘","🥜")
val UNITS = listOf("kg","g","litre","ml","pcs","bottle","pack","box","dozen")
val COLORS = listOf("#FFF3E0","#F3F8E8","#FFF8E1","#FFF0F0","#F0F4FF","#F5F0FF","#E8F8F5","#FFF0E8")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemScreen(viewModel: KitchenViewModel, onBack: () -> Unit) {
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("kg") }
    var price by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("🍚") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    var nameErr by remember { mutableStateOf(false) }
    var qtyErr by remember { mutableStateOf(false) }
    var priceErr by remember { mutableStateOf(false) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) {
        if (it) photoUri = cameraUri
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let { uri -> photoUri = uri }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val file = File.createTempFile("kitchen_", ".jpg", context.getExternalFilesDir(Environment.DIRECTORY_PICTURES))
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            cameraUri = uri
            cameraLauncher.launch(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add Kitchen Item", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(BrownMid, navigationIconContentColor = GoldAccent, titleContentColor = Color.White)
            )
        },
        containerColor = CreamBg
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Photo
            Card(colors = CardDefaults.cardColors(CreamCard), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, CreamBorder)) {
                Column(Modifier.padding(16.dp)) {
                    Text("📷 Photo", fontWeight = FontWeight.Bold, color = TextMid, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFF0E8DC)), contentAlignment = Alignment.Center) {
                            if (photoUri != null) AsyncImage(photoUri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Text(emoji, fontSize = 32.sp)
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }, border = BorderStroke(1.dp, BrownMid), shape = RoundedCornerShape(10.dp)) {
                                Icon(Icons.Default.CameraAlt, null, Modifier.size(15.dp), tint = BrownMid)
                                Spacer(Modifier.width(4.dp))
                                Text("Camera", color = BrownMid, fontSize = 13.sp)
                            }
                            OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, border = BorderStroke(1.dp, BrownLight), shape = RoundedCornerShape(10.dp)) {
                                Icon(Icons.Default.Photo, null, Modifier.size(15.dp), tint = BrownLight)
                                Spacer(Modifier.width(4.dp))
                                Text("Gallery", color = BrownLight, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            // Emoji picker
            Card(colors = CardDefaults.cardColors(CreamCard), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, CreamBorder)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🎨 Icon", fontWeight = FontWeight.Bold, color = TextMid, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    LazyVerticalGrid(GridCells.Fixed(6), Modifier.height(150.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(EMOJIS) { e ->
                            Box(
                                Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp))
                                    .background(if (e == emoji) Color(0xFFFFF3E0) else Color.Transparent)
                                    .border(BorderStroke(if (e == emoji) 2.dp else 1.dp, if (e == emoji) BrownMid else CreamBorder), RoundedCornerShape(8.dp))
                                    .clickable { emoji = e },
                                contentAlignment = Alignment.Center
                            ) { Text(e, fontSize = 20.sp) }
                        }
                    }
                }
            }

            // Name
            OutlinedTextField(name, { name = it; nameErr = false }, Modifier.fillMaxWidth(),
                label = { Text("Item Name *") }, placeholder = { Text("e.g. Basmati Rice") },
                isError = nameErr, supportingText = { if (nameErr) Text("Required") },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrownMid, unfocusedBorderColor = CreamBorder, focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard),
                shape = RoundedCornerShape(12.dp), singleLine = true,
                leadingIcon = { Text("✏️", fontSize = 16.sp) }
            )

            // Price
            OutlinedTextField(price, { price = it; priceErr = false }, Modifier.fillMaxWidth(),
                label = { Text("Price (₹) *") }, placeholder = { Text("Price per unit") },
                isError = priceErr, supportingText = { if (priceErr) Text("Enter valid price") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrownMid, unfocusedBorderColor = CreamBorder, focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard),
                shape = RoundedCornerShape(12.dp), singleLine = true,
                leadingIcon = { Text("₹", fontSize = 15.sp, color = TextMid, fontWeight = FontWeight.Bold) }
            )

            // Qty + Unit
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(quantity, { quantity = it; qtyErr = false }, Modifier.weight(1f),
                    label = { Text("Quantity *") }, isError = qtyErr,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrownMid, unfocusedBorderColor = CreamBorder, focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard),
                    shape = RoundedCornerShape(12.dp), singleLine = true
                )
                var unitExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(unitExpanded, { unitExpanded = it }, Modifier.weight(1f)) {
                    OutlinedTextField(unit, {}, readOnly = true, label = { Text("Unit") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(unitExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = BrownMid, unfocusedBorderColor = CreamBorder, focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard),
                        shape = RoundedCornerShape(12.dp)
                    )
                    ExposedDropdownMenu(unitExpanded, { unitExpanded = false }) {
                        UNITS.forEach { u -> DropdownMenuItem({ Text(u) }, { unit = u; unitExpanded = false }) }
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            // Add button
            Button(
                onClick = {
                    nameErr = name.isBlank()
                    qtyErr = quantity.toDoubleOrNull() == null
                    priceErr = price.toDoubleOrNull() == null
                    if (!nameErr && !qtyErr && !priceErr) {
                        viewModel.addItem(KitchenItem(
                            name = name.trim(), quantity = quantity.toDouble(),
                            unit = unit, price = price.toDouble(),
                            emoji = emoji, photoUri = photoUri?.toString(),
                            colorHex = COLORS.random()
                        ))
                        onBack()
                    }
                },
                Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(BrownMid, GoldAccent),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Add, null, Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("Add to Kitchen Stock", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
