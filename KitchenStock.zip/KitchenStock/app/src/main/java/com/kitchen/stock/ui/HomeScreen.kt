package com.kitchen.stock.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.kitchen.stock.data.KitchenItem
import com.kitchen.stock.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: KitchenViewModel,
    onAddItem: () -> Unit
) {
    val items by viewModel.items.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var selectedItem by remember { mutableStateOf<KitchenItem?>(null) }
    var showUseSheet by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<KitchenItem?>(null) }

    Box(Modifier.fillMaxSize().background(CreamBg)) {
        Column(Modifier.fillMaxSize()) {

            // Header
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.linearGradient(listOf(BrownDark, BrownMid)))
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🍳", fontSize = 28.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("MY KITCHEN", color = GoldAccent, fontSize = 10.sp, letterSpacing = 3.sp)
                            Text("Stock Manager", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatCard("📦", "${stats.first}", "ITEMS", Modifier.weight(1f))
                        StatCard("💰", "₹${fmtNum(stats.second.toLong())}", "VALUE", Modifier.weight(1f))
                        StatCard("⚠️", "${stats.third}", "LOW", Modifier.weight(1f))
                    }
                }
            }

            // Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = viewModel::setSearch,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                placeholder = { Text("Search items...", color = TextLight) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = TextLight) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty())
                        IconButton(onClick = { viewModel.setSearch("") }) {
                            Icon(Icons.Default.Clear, null, tint = TextLight)
                        }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BrownMid, unfocusedBorderColor = CreamBorder,
                    focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard
                ),
                shape = RoundedCornerShape(14.dp), singleLine = true
            )

            if (items.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🏪", fontSize = 52.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (searchQuery.isBlank()) "No items yet\nTap + to add your first item"
                            else "No results for \"$searchQuery\"",
                            color = TextLight, fontSize = 14.sp, textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(items, key = { it.id }) { item ->
                        ItemCard(item,
                            onUse = { selectedItem = item; showUseSheet = true },
                            onDelete = { deleteTarget = item }
                        )
                    }
                }
            }
        }

        // FAB
        FloatingActionButton(
            onClick = onAddItem,
            modifier = Modifier.align(Alignment.BottomEnd).padding(24.dp),
            containerColor = BrownMid, contentColor = GoldAccent, shape = CircleShape
        ) {
            Icon(Icons.Default.Add, null, Modifier.size(28.dp))
        }
    }

    if (showUseSheet && selectedItem != null) {
        UseItemSheet(selectedItem!!,
            onDismiss = { showUseSheet = false; selectedItem = null },
            onConfirm = { qty ->
                viewModel.useItem(selectedItem!!, qty)
                showUseSheet = false; selectedItem = null
            }
        )
    }

    deleteTarget?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Remove Item?") },
            text = { Text("Remove ${item.emoji} ${item.name} from stock?") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteItem(item); deleteTarget = null }) {
                    Text("Remove", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel", color = BrownMid) }
            },
            containerColor = CreamCard
        )
    }
}

@Composable
fun StatCard(icon: String, value: String, label: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(Color.White.copy(0.1f)), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 16.sp)
            Text(value, color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
            Text(label, color = Color.White.copy(0.5f), fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun ItemCard(item: KitchenItem, onUse: () -> Unit, onDelete: () -> Unit) {
    val bg = runCatching { Color(android.graphics.Color.parseColor(item.colorHex)) }
        .getOrDefault(Color(0xFFFFF3E0))
    val isLow = item.quantity <= 2

    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(bg), elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(0.7f)),
                contentAlignment = Alignment.Center
            ) {
                if (item.photoUri != null) {
                    AsyncImage(item.photoUri, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text(item.emoji, fontSize = 28.sp)
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(item.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextDark,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isLow) Color(0xFFFFEBE6) else Color.Black.copy(0.06f),
                        border = BorderStroke(1.dp, if (isLow) Color(0xFFFF8A60) else CreamBorder)
                    ) {
                        Text("${fmtQty(item.quantity)} ${item.unit}",
                            Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                            fontSize = 11.sp, color = if (isLow) ErrorRed else TextMid, fontWeight = FontWeight.SemiBold)
                    }
                    if (isLow) Text("Low!", fontSize = 10.sp, color = ErrorRed)
                }
                Text("₹${fmtNum(item.price.toLong())}/${item.unit}  •  Total: ₹${fmtNum((item.price * item.quantity).toLong())}",
                    color = TextLight, fontSize = 11.sp)
            }

            Spacer(Modifier.width(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = onUse,
                    colors = ButtonDefaults.buttonColors(BrownMid, GoldAccent),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    modifier = Modifier.height(32.dp)
                ) { Text("USE", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                OutlinedButton(onClick = onDelete,
                    border = BorderStroke(1.dp, ErrorRed),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    modifier = Modifier.height(32.dp)
                ) { Text("DEL", fontSize = 11.sp, color = ErrorRed) }
            }
        }
    }
}

fun fmtQty(qty: Double) = if (qty == qty.toLong().toDouble()) qty.toLong().toString() else "%.1f".format(qty)
fun fmtNum(n: Long): String = NumberFormat.getNumberInstance(Locale("en", "IN")).format(n)
