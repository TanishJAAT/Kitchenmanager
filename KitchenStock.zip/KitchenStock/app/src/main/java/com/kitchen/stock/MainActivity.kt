package com.kitchen.stock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.kitchen.stock.theme.KitchenStockTheme
import com.kitchen.stock.ui.AddItemScreen
import com.kitchen.stock.ui.HomeScreen
import com.kitchen.stock.ui.KitchenViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KitchenStockTheme { KitchenApp() }
        }
    }
}

@Composable
fun KitchenApp() {
    val nav = rememberNavController()
    val vm: KitchenViewModel = viewModel()
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm) { nav.navigate("add") } }
        composable("add")  { AddItemScreen(vm) { nav.popBackStack() } }
    }
}
