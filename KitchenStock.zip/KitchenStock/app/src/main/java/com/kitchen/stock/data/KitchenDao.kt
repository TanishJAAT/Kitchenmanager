package com.kitchen.stock.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KitchenDao {
    @Query("SELECT * FROM kitchen_items ORDER BY createdAt DESC")
    fun getAllItems(): Flow<List<KitchenItem>>

    @Query("SELECT * FROM kitchen_items WHERE name LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchItems(query: String): Flow<List<KitchenItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: KitchenItem)

    @Update
    suspend fun updateItem(item: KitchenItem)

    @Delete
    suspend fun deleteItem(item: KitchenItem)

    @Query("UPDATE kitchen_items SET quantity = :newQty WHERE id = :id")
    suspend fun updateQuantity(id: Int, newQty: Double)
}
