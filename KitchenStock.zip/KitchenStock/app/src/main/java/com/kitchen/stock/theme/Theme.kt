package com.kitchen.stock.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrownDark    = Color(0xFF3D1A00)
val BrownMid     = Color(0xFF7A3200)
val BrownLight   = Color(0xFFC05A00)
val GoldAccent   = Color(0xFFFFD580)
val CreamBg      = Color(0xFFFDFAF5)
val CreamCard    = Color(0xFFFFF8F0)
val CreamBorder  = Color(0xFFE0C8A8)
val TextDark     = Color(0xFF2D1200)
val TextMid      = Color(0xFF7A5030)
val TextLight    = Color(0xFFBBA080)
val ErrorRed     = Color(0xFFCC3A1A)

private val KitchenColorScheme = lightColorScheme(
    primary           = BrownMid,
    onPrimary         = GoldAccent,
    primaryContainer  = Color(0xFFFFF3E0),
    secondary         = BrownLight,
    background        = CreamBg,
    surface           = CreamCard,
    onBackground      = TextDark,
    onSurface         = TextDark,
    error             = ErrorRed,
)

@Composable
fun KitchenStockTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = KitchenColorScheme, content = content)
}
