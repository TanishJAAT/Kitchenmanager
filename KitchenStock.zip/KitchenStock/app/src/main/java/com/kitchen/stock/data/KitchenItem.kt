package com.kitchen.stock.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "kitchen_items")
data class KitchenItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val quantity: Double,
    val unit: String,
    val price: Double,
    val emoji: String = "🍚",
    val photoUri: String? = null,
    val colorHex: String = "#FFF3E0",
    val createdAt: Long = System.currentTimeMillis()
)
