package com.kitchen.stock.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kitchen.stock.data.KitchenItem
import com.kitchen.stock.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UseItemSheet(item: KitchenItem, onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var usedQty by remember { mutableStateOf(1.0) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = CreamBg,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(item.emoji, fontSize = 48.sp)
            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = TextDark)
            Text("Available: ${fmtQty(item.quantity)} ${item.unit}", color = TextLight, fontSize = 13.sp)
            Spacer(Modifier.height(24.dp))
            Text("How much did you use?", fontWeight = FontWeight.SemiBold, color = TextMid)
            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                FilledIconButton(
                    onClick = { if (usedQty > 0.5) usedQty = (usedQty - 0.5).coerceAtLeast(0.5) },
                    colors = IconButtonDefaults.filledIconButtonColors(Color(0xFFFFF3E0), BrownMid),
                    modifier = Modifier.size(44.dp)
                ) { Text("−", fontSize = 22.sp, fontWeight = FontWeight.Bold) }

                Column(Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(fmtQty(usedQty), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = BrownDark)
                    Text(item.unit, color = TextLight, fontSize = 13.sp)
                }

                FilledIconButton(
                    onClick = { if (usedQty < item.quantity) usedQty = (usedQty + 0.5).coerceAtMost(item.quantity) },
                    colors = IconButtonDefaults.filledIconButtonColors(Color(0xFFFFF3E0), BrownMid),
                    modifier = Modifier.size(44.dp)
                ) { Text("+", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            }

            Spacer(Modifier.height(12.dp))

            val remaining = (item.quantity - usedQty).coerceAtLeast(0.0)
            Surface(
                color = if (remaining <= 0) Color(0xFFFFEBE6) else Color(0xFFE8F5E9),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(
                    if (remaining <= 0) "⚠️ Item will be removed from stock!"
                    else "Remaining: ${fmtQty(remaining)} ${item.unit}",
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 12.sp,
                    color = if (remaining <= 0) ErrorRed else Color(0xFF2E7D32)
                )
            }

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { onConfirm(usedQty) },
                Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(BrownMid, GoldAccent),
                shape = RoundedCornerShape(14.dp)
            ) { Text("✓  Mark as Used", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
