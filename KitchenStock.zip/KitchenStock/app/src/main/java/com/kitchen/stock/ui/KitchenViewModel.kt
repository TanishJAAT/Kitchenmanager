package com.kitchen.stock.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kitchen.stock.data.KitchenDatabase
import com.kitchen.stock.data.KitchenItem
import com.kitchen.stock.data.KitchenRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class KitchenViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KitchenRepository(
        KitchenDatabase.getDatabase(application).kitchenDao()
    )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val items: StateFlow<List<KitchenItem>> = _searchQuery
        .debounce(300)
        .flatMapLatest { repository.searchItems(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stats: StateFlow<Triple<Int, Double, Int>> = items.map { list ->
        Triple(
            list.size,
            list.sumOf { it.price * it.quantity },
            list.count { it.quantity <= 2 }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Triple(0, 0.0, 0))

    fun setSearch(q: String) { _searchQuery.value = q }

    fun addItem(item: KitchenItem) = viewModelScope.launch { repository.addItem(item) }
    fun deleteItem(item: KitchenItem) = viewModelScope.launch { repository.deleteItem(item) }
    fun useItem(item: KitchenItem, qty: Double) = viewModelScope.launch { repository.useItem(item, qty) }
}
